var form = document.querySelector('form');
var movieContainer = document.querySelector('.movie_container');
var input_box = document.querySelector('.input-box');

// Function to fetch data from API
var getInfo = async (moviename) => {
    const myapikey = "b8da9797";
    const url = `https://www.omdbapi.com/?apikey=${myapikey}&t=${moviename}`;
    const response = await fetch(url);
    const data = await response.json();

    console.log(data);
    showMovieData(data);
}

// Function to show data 
var showMovieData = (data) => {
    movieContainer.innerHTML = "";

    // Check for valid response
    if (data.Response === "False") {
        movieContainer.innerHTML = `<p>Movie not found. Please try another title.</p>`;
        return;
    }

    // Destructuring assignment
    const { Title, imdbRating, Genre, Released, Runtime, Actors, Plot, Poster } = data;

    // Create movie info element
    const movieElement = document.createElement('div');
    movieElement.classList.add('movie-info');

    movieElement.innerHTML = `
        <h2>${Title}</h2>
        <p><strong>Rating: </strong>★ ${imdbRating}</p>
        <p><strong>Release Date: </strong>${Released}</p>
        <p><strong>Duration: </strong>${Runtime}</p>
        <p><strong>Actors: </strong>${Actors}</p>
        <p><strong>Plot: </strong>${Plot}</p>
    `;

    // Create genre elements
    const movieGenreElement = document.createElement('div');
    movieGenreElement.classList.add('movie-genre');

    Genre.split(",").forEach(element => {
        const p = document.createElement('p');
        p.textContent = element.trim();
        movieGenreElement.appendChild(p);
    });

    movieElement.appendChild(movieGenreElement);

    // Create poster element
    const moviePosterElement = document.createElement('div');
    moviePosterElement.classList.add('movie-poster');
    moviePosterElement.innerHTML = `
        <img src="${Poster !== "N/A" ? Poster : 'https://via.placeholder.com/300x450?text=No+Image'}" alt="${Title} Poster" />
    `;

    // Append elements to the container
    movieContainer.appendChild(moviePosterElement);
    movieContainer.appendChild(movieElement);
}

// Add event listener for form submission
form.addEventListener('submit', (e) => {
    e.preventDefault();
    const moviename = input_box.value.trim();

    if (moviename !== '') {
        getInfo(moviename);
    }
});
